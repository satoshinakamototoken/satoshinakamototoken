🐶 Viralata Finance REAU token smart contract 🐶

Brazil's #1 Decentralised Financial Ecosystem.

https://viralata.finance

Feel free to read the code.

Deployed Contracts / Hash

BSCMAINNET

Viralata Finance (REAU) - https://bscscan.com/token/0x4c79b8c9cB0BD62B047880603a9DEcf36dE28344
